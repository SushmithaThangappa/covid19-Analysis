# Databricks notebook source
dbutils.secrets.listScopes()

# COMMAND ----------

clientId = dbutils.secrets.get('secret-scope-covid19','c19-clientID')
tenantId = dbutils.secrets.get('secret-scope-covid19','c19-tenantID')
clientSecret = dbutils.secrets.get('secret-scope-covid19','c19-secret')

# COMMAND ----------

# Set up the configurations for service principal authentication
configs = {
    "fs.azure.account.auth.type": "OAuth",
    "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
    "fs.azure.account.oauth2.client.id": clientId,
    "fs.azure.account.oauth2.client.secret": clientSecret,
    "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenantId}/oauth2/token"
}

# COMMAND ----------

clientId = dbutils.secrets.get('secret-scope-covid19','c19-clientID')
tenantId = dbutils.secrets.get('secret-scope-covid19','c19-tenantID')
clientSecret = dbutils.secrets.get('secret-scope-covid19','c19-secret')
# Set up the configurations for service principal authentication
configs = {
    "fs.azure.account.auth.type": "OAuth",
    "fs.azure.account.oauth.provider.type": "org.apache.hadoop.fs.azurebfs.oauth2.ClientCredsTokenProvider",
    "fs.azure.account.oauth2.client.id": clientId,
    "fs.azure.account.oauth2.client.secret": clientSecret,
    "fs.azure.account.oauth2.client.endpoint": f"https://login.microsoftonline.com/{tenantId}/oauth2/token"
}
def mount_storage(container_name, storage_account_name):
    container_name = container_name
    storage_account_name = storage_account_name
    mount_point = f"/mnt/{container_name}"
    if mount_point not in [mount.mountPoint for mount in dbutils.fs.mounts()]:
        # Mount the storage
        dbutils.fs.mount(
            source=f"abfss://{container_name}@{storage_account_name}.dfs.core.windows.net/",
            mount_point=mount_point,
            extra_configs=configs
        )

# COMMAND ----------

mount_storage('raw','sacovid19reportingdlake')
mount_storage('processed','sacovid19reportingdlake')

# COMMAND ----------

display(dbutils.fs.mounts())